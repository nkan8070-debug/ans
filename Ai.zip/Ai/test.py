monkey, box, banana = "door", "middle", "ceiling"
print("Monkey is at:", monkey)

if monkey != box:
    monkey = box
    print("Monkey walks to the box.")

if monkey == box:
    box = monkey = "below banana"
    print("Monkey pushes the box below the banana.")

if monkey == box == "below banana":
    monkey = "on box"
    print("Monkey climbs on the box.")

if monkey == "on box" and box == "below banana":
    print("Monkey gets the banana!")
    print("Goal State Achieved.")
else:
    print("Goal State Not Achieved.")